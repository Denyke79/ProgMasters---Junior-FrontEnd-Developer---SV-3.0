module.exports = {
    coverageProvider: "v8",
    testEnvironment: "node"
};