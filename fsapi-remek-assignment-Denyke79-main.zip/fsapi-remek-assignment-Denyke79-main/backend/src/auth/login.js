const jwt = require('jsonwebtoken');

const userDB = [
    { _id: 1, "username": "user", "password": "user_pw", role: "USER", "name": "User" },
    { _id: 2, "username": 'admin', "password": "admin_pw", role: "ADMIN", "name": "Admin" },
    { _id: 3, "username": 'fdani', "password": "admin_pw", role: "ADMIN", "name": "Fazekas Dani" },
];

module.exports = (req, res, next) => {
    if (!req.body['username'] || !req.body['password']) {
        return res.status(400).send('Missing username or password');
    }

    const user = userDB
        .find(u => u.username === req.body['username'] && u.password === req.body['password']);

    if (!user) {
        return res.status(404).send('Invalid username or password');
    }

    const accessToken = jwt.sign({
        username: user.username,
        password: user.password,
        role: user.role,
        user_id: user._id,
        name: user.name
    }, process.env.ACCESS_TOKEN_SECRET_KEY, {
        expiresIn: process.env.ACCESS_TOKEN_EXPIRY
    })

    res.json({ accessToken })
}