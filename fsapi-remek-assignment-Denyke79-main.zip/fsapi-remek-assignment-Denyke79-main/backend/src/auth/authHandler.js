const jwt = require('jsonwebtoken');

const userDB = [
    { _id: 1, "username": "user", "password": "user_pw", role: "USER", "name": "User" },
    { _id: 2, "username": 'admin', "password": "admin_pw", role: "ADMIN", "name": "Admin" },
    { _id: 3, "username": 'fdani', "password": "admin_pw", role: "ADMIN", "name": "Fazekas Dani" },
];

const refreshDB = [];

exports.login = (req, res, next) => {
    if (!req.body['username'] || !req.body['password']) {
        return res.status(400).send('Missing username or password');
    }

    //Lekérdezés a DB -ból
    const user = userDB
        .find(u => u.password === req.body['password'] && u.username === req.body['username']);

    if (!user) {
        return res.status(404).send('Invalid username or password');
    }

    const accessToken = jwt.sign({
        username: user.username,
        role: user.role,
        user_id: user._id,
        name: user.name
    }, process.env.ACCESS_TOKEN_SECRET_KEY, {
        expiresIn: process.env.ACCESS_TOKEN_EXPIRY
    })

    const refreshToken = jwt.sign({
        username: user.username,
        role: user.role,
        user_id: user._id,
        name: user.name
    }, process.env.REFRESH_TOKEN_SECRET_KEY)

    refreshDB.push(refreshToken);
    res.json({
        accessToken, refreshToken, user: {
            username: user.username,
            role: user.role,
            user_id: user._id,
            name: user.name
        }
    })
}

exports.refresh = (req, res, next) => {
    const refreshToken = req.body['refreshToken'];

    if (!refreshToken) {
        return res.sendStatus(403);
    }

    const foundToken = refreshDB.includes(refreshToken);
    if (foundToken) {
        jwt.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET_KEY, (err, payLoad) => {
            if (err) {
                return res.sendStatus(403);
            }

            const accessToken = jwt.sign({
                username: payLoad.username,
                user_id: payLoad.user_id,
                role: payLoad.role,
                name: payLoad.name
            }, process.env.ACCESS_TOKEN_SECRET_KEY, {
                expiresIn: process.env.ACCESS_TOKEN_EXPIRY
            })
            res.json({ accessToken })
        })
    }
}

exports.logout = (req, res, next) => {
    const { refreshToken } = req.body;

    if (!refreshToken) {
        return res.sendStatus(403);
    }

    const tokenId = refreshDB.findIndex(t => t === refreshToken);
    if (tokenId >= 0) {
        refreshDB.splice(tokenId, 1);
        res.sendStatus(200);
    } else {
        res.sendStatus(403);
    }
}

exports.me = (req, res, next) => {
    const authorization = req.headers.authorization;
    const token = authorization.split(' ')[1];

    jwt.verify(token, process.env.ACCESS_TOKEN_SECRET_KEY, (err, user) => {

        if (!err) {
            res.json({ user })
        }
    })
}