const userService = jest.mock('./user.service')

let mockData;

userService.findById = jest.fn(id => {
    return Promise.resolve(mockData.find(i => i.id === id))
});

userService.create = jest.fn(newUser => {
    const savedUser = {
        ...newUser,
        id: mockData[mockData.length - 1].id + 1
    }
    mockData.push(savedUser)
    return Promise.resolve(savedUser);
})

userService.__setMockData = data => {
    mockData = data;
}


module.exports = userService;