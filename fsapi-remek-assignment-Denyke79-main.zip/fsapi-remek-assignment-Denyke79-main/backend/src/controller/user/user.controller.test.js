const { mockRequest, mockResponse } = require('jest-mock-req-res');
const createError = require('http-errors');
const userController = require('./user.controller');
const userService = require('./user.service');
jest.mock('./user.service.js');

describe('UserController tests', () => {
    let mockData;
    let nextFunction;
    let response;

    beforeEach(() => {
        mockData = [{
            "id": 1,
            "name": "Első János",
            "userName": "elsojani",
            "password": "janielso",
            "role": "user",
            "institutions": "Veres"
        }, {
            "id": 2,
            "name": "Második Béle",
            "userName": "masodikbela",
            "password": "belamasodik",
            "role": "user",
            "institutions": "Jedlik"
        }, {
            "id": 3,
            "name": "Harmadik Gizella",
            "userName": "harmadikgizi",
            "password": "giziharmadik",
            "role": "admin",
            "institutions": "Veres"
        }];

        userService.__setMockData(mockData);
        nextFunction = jest.fn();
        response = mockResponse();
    });

    afterEach(() => {
        jest.clearAllMocks();
    })

    test("create() with valid request body", async () => {

        const validSavedUser = {
            id: mockData[mockData.length - 1].id + 1,
            name: 'Fekete István',
            userName: 'feketeisti',
            password: 'istifekete',
            role: 'user',
            institutions: 'Veres'
        }

        const request = mockRequest({
            body: {
                'name': validSavedUser.name,
                'userName': validSavedUser.userName,
                'password': validSavedUser.password,
                'role': validSavedUser.role,
                'institutions': validSavedUser.institutions,
            }
        });

        const saveObj = {
            name: validSavedUser.name,
            userName: validSavedUser.userName,
            password: validSavedUser.password,
            role: validSavedUser.role,
            institutions: validSavedUser.institutions
        };

        await userController.create(request, response, nextFunction)

        expect(userService.create).toBeCalledWith(saveObj);
        expect(nextFunction).not.toBeCalled();
        expect(response.json).toBeCalledWith(validSavedUser);
        expect(response.json).toBeCalledTimes(1);
        expect(response.status).toBeCalledWith(201)
    })

    test('findById() with valid ID', () => {
        const VALID_USER_ID = 2;

        const request = mockRequest({
            params: {
                id: VALID_USER_ID
            }
        });

        return userController.findById(request, response, nextFunction)
            .then(() => {
                expect(userService.findById).toBeCalledWith(VALID_USER_ID);
                expect(userService.findById).toBeCalledTimes(1)
                expect(response.json).toBeCalledWith(mockData.find(i => i.id === VALID_USER_ID))
            })
    })
})