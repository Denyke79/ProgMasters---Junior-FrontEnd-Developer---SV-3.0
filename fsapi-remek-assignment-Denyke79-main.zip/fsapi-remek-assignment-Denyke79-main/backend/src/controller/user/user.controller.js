const createError = require('http-errors');
const logger = require('../../config/logger');
const userService = require('./user.service');

exports.findAll = async (req, res, next) => {
    logger.debug(`${new Date().toUTCString()}, METHOD: ${req.method}, path:${req.originalUrl}`)
    try {
        const users = await userService.findAll();
        res.json(users);
    } catch (err) {
        logger.error(err);
        return next(new createError.InternalServerError('Database error'));
    }
}

exports.findById = (req, res, next) => {
    return userService.findById(req.params.id)
        .then(user => {
            if (!user) {
                return next(new createError.NotFound("User is not found"));
            }
            return res.json(user);
        });
};

exports.delete = (req, res, next) => {
    return userService.delete(req.params.id)
        .then(() => res.json({}))
        .catch(err => {
            next(new createError.InternalServerError(err.message));
        });
};

exports.create = (req, res, next) => {
    return userService.create(req.body)
        .then(cp => {
            res.status(201);
            res.json(cp);
        })
        .catch(err => next(new createError.InternalServerError(err.message)));
};

exports.update = async (req, res, next) => {
    const userId = req.params.id;

    try {
        const updatedUser = await userService.update(userId, req.body);
        res.json(updatedUser);
    } catch (err) {
        logger.error(err);
        return next(new createError.InternalServerError('Could not updated!'));
    }
};