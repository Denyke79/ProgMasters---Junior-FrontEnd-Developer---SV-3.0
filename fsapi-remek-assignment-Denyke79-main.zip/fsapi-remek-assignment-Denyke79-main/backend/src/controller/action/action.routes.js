const express = require('express');
const router = express.Router();
const actionController = require('./action.controller');

router.post('/', (req, res, next) => {
    return actionController.create(req, res, next)
})

router.get('/', (req, res, next) => {
    return actionController.findAll(req, res, next)
})

router.get('/:id', (req, res, next) => {
    return actionController.findById(req, res, next)
})

router.put('/:id', (req, res, next) => {
    return actionController.update(req, res, next)
})

router.delete('/:id', (req, res, next) => {
    return actionController.delete(req, res, next)
})

module.exports = router;