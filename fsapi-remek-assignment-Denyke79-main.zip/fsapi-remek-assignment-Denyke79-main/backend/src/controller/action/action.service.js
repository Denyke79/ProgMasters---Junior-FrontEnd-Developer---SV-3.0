const Action = require('../../models/action.model');

exports.create = action => {
    const newAction = new Action(action);
    return newAction.save();
};

exports.findAll = () => Action.find();

exports.findById = id => Action.findById(id);

exports.update = (id, actionData) => Action.findByIdAndUpdate(id, actionData, { new: true });

exports.delete = id => Action.findByIdAndRemove(id);