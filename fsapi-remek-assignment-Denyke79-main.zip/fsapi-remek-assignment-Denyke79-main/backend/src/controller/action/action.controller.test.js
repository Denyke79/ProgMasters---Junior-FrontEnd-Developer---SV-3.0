const { mockRequest, mockResponse } = require('jest-mock-req-res');
const actionController = require('./action.controller');
const actionService = require('./action.service');
jest.mock('./action.service.js');

describe('ActionController tests', () => {
    let mockData;
    let nextFunction;
    let response;

    beforeEach(() => {
        mockData = [{
            "id": 1,
            "date": '2023.04.02',
            "institution": "Veres",
            "clientName": "Dr. Bogdán Jenő",
            "affectedChildName": "Kis Balázs",
            "clientType": "osztályfőnök",
            "headcount": 1,
            "newClient": false,
            "workingMethod": "Szóbeli egyeztetés",
            "activity": "Tanácsadás",
            "problem": "Beilleszkedési nehézség",
        }, {
            "id": 2,
            "date": '2023.04.06',
            "institution": "Veres",
            "clientName": "Kis Balázs",
            "affectedChildName": "Kis Balázs",
            "clientType": "gyerek",
            "headcount": 1,
            "newClient": false,
            "workingMethod": "Szóbeli egyeztetés",
            "activity": "Tanácsadás",
            "problem": "Beilleszkedési nehézség",
        }, {
            "id": 3,
            "date": '2023.04.10',
            "institution": "Lukács",
            "clientName": "9/a",
            "affectedChildName": "9/a",
            "clientType": "osztály",
            "headcount": 16,
            "newClient": true,
            "workingMethod": "csoportos",
            "activity": "Készségfejlesztő csoportfoglalkozás",
            "problem": "nincs",
        }];

        actionService.__setMockData(mockData);
        nextFunction = jest.fn();
        response = mockResponse();
    });

    afterEach(() => {
        jest.clearAllMocks();
    })

    test('findById() with valid ID', () => {
        const VALID_ACTION_ID = 2;

        const request = mockRequest({
            params: {
                id: VALID_ACTION_ID
            }
        });

        return actionController.findById(request, response, nextFunction)
            .then(() => {
                expect(actionService.findById).toBeCalledWith(VALID_ACTION_ID);
                expect(actionService.findById).toBeCalledTimes(1)
                expect(response.json).toBeCalledWith(mockData.find(i => i.id === VALID_ACTION_ID))
            })
    })
})