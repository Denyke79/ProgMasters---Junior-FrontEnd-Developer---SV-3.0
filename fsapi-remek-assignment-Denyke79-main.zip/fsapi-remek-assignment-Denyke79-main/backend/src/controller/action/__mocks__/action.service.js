const actionService = jest.mock('./action.service')

let mockData;

actionService.findById = jest.fn(id => {
    return Promise.resolve(mockData.find(i => i.id === id))
});

actionService.create = jest.fn(newAction => {
    const savedAction = {
        ...newAction,
        id: mockData[mockData.length - 1].id + 1
    }
    mockData.push(savedAction)
    return Promise.resolve(savedAction);
})

actionService.__setMockData = data => {
    mockData = data;
}


module.exports = actionService;