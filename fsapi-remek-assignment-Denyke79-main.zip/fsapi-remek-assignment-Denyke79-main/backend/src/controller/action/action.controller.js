const createError = require('http-errors');
const logger = require('../../config/logger');
const actionService = require('./action.service');

exports.findAll = async (req, res, next) => {
    logger.debug(`${new Date().toUTCString()}, METHOD: ${req.method}, path:${req.originalUrl}`)
    try {
        const actions = await actionService.findAll();
        res.json(actions);
    } catch (err) {
        logger.error(err);
        return next(new createError.InternalServerError('Database error'));
    }
}

exports.findById = (req, res, next) => {
    return actionService.findById(req.params.id)
        .then(action => {
            if (!action) {
                return next(new createError.NotFound("Action is not found"));
            }
            return res.json(action);
        });
};

exports.delete = (req, res, next) => {
    return actionService.delete(req.params.id)
        .then(() => res.json({}))
        .catch(err => {
            next(new createError.InternalServerError(err.message));
        });
};

exports.create = (req, res, next) => {
    return actionService.create(req.body)
        .then(cp => {
            res.status(201);
            res.json(cp);
        })
        .catch(err => next(new createError.InternalServerError(err.message)));
};

exports.update = async (req, res, next) => {
    const actionId = req.params.id;

    try {
        const updatedAction = await actionService.update(actionId, req.body);
        res.json(updatedAction);
    } catch (err) {
        logger.error(err);
        return next(new createError.InternalServerError('Could not updated!'));
    }
};