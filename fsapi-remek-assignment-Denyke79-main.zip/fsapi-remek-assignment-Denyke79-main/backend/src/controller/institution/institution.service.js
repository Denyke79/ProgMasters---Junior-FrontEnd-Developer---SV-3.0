const Institution = require('../../models/institution.model');

exports.findAll = () => Institution.find().sort({ name: 1 }).collation({ locale: 'hu' });

exports.findById = id => Institution.findById(id);