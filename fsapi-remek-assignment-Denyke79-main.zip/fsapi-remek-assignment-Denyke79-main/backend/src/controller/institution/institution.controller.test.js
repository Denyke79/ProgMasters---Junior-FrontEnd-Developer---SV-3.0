const { mockRequest, mockResponse } = require('jest-mock-req-res');
const institutionController = require('./institution.controller');
const institutionService = require('./institution.service');
jest.mock('./institution.service.js');

describe('InstitutionController tests', () => {
    let mockData;
    let nextFunction;
    let response;

    beforeEach(() => {
        mockData = [{
            "id": 1,
            "name": "Veres Iskola",
            "shortName": "Veres",
            "socialWorkerName": "Szandi",
            "socailWorkerEmail": "iskolai8@mail.com",
            "socialWorkerPhone": "+36302222"
        }, {
            "id": 2,
            "name": "Jedlik Ányos Középiskola",
            "shortName": "Jedlik",
            "socialWorkerName": "Ági",
            "socailWorkerEmail": "iskolai18@mail.com",
            "socialWorkerPhone": "+36302232"
        }, {
            "id": 3,
            "name": "Sün Balázs Tagóvoda",
            "shortName": "Süni Ovi",
            "socialWorkerName": "Ági",
            "socailWorkerEmail": "iskolai18@mail.com",
            "socialWorkerPhone": "+36302232"
        }];

        institutionService.__setMockData(mockData);
        nextFunction = jest.fn();
        response = mockResponse();
    });

    afterEach(() => {
        jest.clearAllMocks();
    })

    test('findById() with valid ID', () => {
        const VALID_ACTION_ID = 2;

        const request = mockRequest({
            params: {
                id: VALID_ACTION_ID
            }
        });

        return institutionController.findById(request, response, nextFunction)
            .then(() => {
                expect(institutionService.findById).toBeCalledWith(VALID_ACTION_ID);
                expect(institutionService.findById).toBeCalledTimes(1)
                expect(response.json).toBeCalledWith(mockData.find(i => i.id === VALID_ACTION_ID))
            })
    })

})