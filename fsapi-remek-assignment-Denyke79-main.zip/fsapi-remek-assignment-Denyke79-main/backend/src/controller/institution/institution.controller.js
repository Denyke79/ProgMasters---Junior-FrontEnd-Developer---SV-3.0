const createError = require('http-errors');
const logger = require('../../config/logger');
const institutionService = require('./institution.service');

exports.findAll = async (req, res, next) => {
    logger.debug(`${new Date().toUTCString()}, METHOD: ${req.method}, path:${req.originalUrl}`)
    try {
        const institutions = await institutionService.findAll();
        res.json(institutions);
    } catch (err) {
        logger.error(err);
        return next(new createError.InternalServerError('Database error'));
    }
}

exports.findById = async (req, res, next) => {
    const id = req.params.id;
    try {
        const institution = await institutionService.findById(id, {});
        res.json(institution)
    } catch (err) {
        logger.error(err);
        return next(new createError.InternalServerError('Database error'))
    }
}

