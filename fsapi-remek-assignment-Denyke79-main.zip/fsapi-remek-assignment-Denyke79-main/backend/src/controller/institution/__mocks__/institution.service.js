const institutionService = jest.mock('./institution.service')

let mockData;

institutionService.findById = jest.fn(id => {
    return Promise.resolve(mockData.find(i => i.id === id))
});

institutionService.create = jest.fn(newInstitution => {
    const savedInstitution = {
        ...newInstitution,
        id: mockData[mockData.length - 1].id + 1
    }
    mockData.push(savedInstitution)
    return Promise.resolve(savedInstitution);
})

institutionService.__setMockData = data => {
    mockData = data;
}


module.exports = institutionService;