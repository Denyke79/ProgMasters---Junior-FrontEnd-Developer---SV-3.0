const actionValidator = {};

actionValidator.actionSaving = action => {
    let errorMessage = '';
    if (!case_["date"] ||
        !case_["institutionName"] ||
        !case_["shortName"] ||
        !case_["institutionType"] ||
        !case_["actionName"] ||
        !case_["affectedName"] ||
        !case_["clientType"] ||
        !case_["headcount"] ||
        !case_["newClient"] ||
        !case_["workingMethod"] ||
        !case_["activity"] ||
        !case_["problem"]) {
        errorMessage = 'Body must contain all properties, expect comment';
    }
    return errorMessage;
};

module.exports = actionValidator