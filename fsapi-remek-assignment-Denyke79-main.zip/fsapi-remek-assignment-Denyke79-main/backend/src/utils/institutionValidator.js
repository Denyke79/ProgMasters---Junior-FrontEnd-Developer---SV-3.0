const institutionValidator = {};

institutionValidator.institutionSaving = institution => {
    let errorMessage = '';
    if (!institution["name"] || !institution["shortName"]) {
        errorMessage = 'Body must contain name and shortname';
    }
    return errorMessage;
};

module.exports = institutionValidator