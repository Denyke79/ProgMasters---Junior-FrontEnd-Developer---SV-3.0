const userValidator = {};

userValidator.userSaving = user => {
    let errorMessage = '';
    if (!user["name"] || !user["userName"] || !user["password"] || !user["role"] || !user["institutions"]) {
        errorMessage = 'Body must contain all properties';
    }
    return errorMessage;
}

module.exports = userValidator