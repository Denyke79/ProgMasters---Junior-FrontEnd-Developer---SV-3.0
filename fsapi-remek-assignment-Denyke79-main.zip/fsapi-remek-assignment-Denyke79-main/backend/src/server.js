require('dotenv').config();
const config = require('config');
const express = require('express');
const morgan = require('morgan');
const { join } = require('path');
const logger = require('./config/logger');

const cors = require('cors');
const corsConfig = config.cors;

const authenticateJWT = require('./auth/authenticate');
const adminAuth = require('./auth/adminOnly');
const authHandler = require('./auth/authHandler');

const angularAppPath = join(__dirname, '..', 'public', 'angular');

const swaggerUi = require('swagger-ui-express');
const YAML = require('yamljs');
const swaggerDocument = YAML.load('./docs/swagger.yaml');

const app = express();
const apiWrapper = express();
apiWrapper.use('/api', app);

app.use(morgan('combined', { stream: { write: (message) => logger.info(message) } }));

app.use(express.json());
app.use(express.static('public'));

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

app.post('/login', authHandler.login);
app.post('/refresh', authHandler.refresh);
app.post('/logout', authHandler.logout);
app.get('/me', authHandler.me);

app.use('/user', authenticateJWT, adminAuth, require('./controller/user/user.routes'));
app.use('/institution', require('./controller/institution/institution.routes'));
app.use('/action', authenticateJWT, require('./controller/action/action.routes'));

apiWrapper.use('/', express.static(angularAppPath));
apiWrapper.get('*', (req, res) => {
    res.sendFile(angularAppPath + '/index.html')
})

app.use((err, req, res, next) => {
    logger.error(`ERROR ${err.statusCode}: ${err.message}`);
    res.status(err.statusCode);
    res.json({
        hasError: true,
        message: err.message
    })
})

module.exports = apiWrapper;
