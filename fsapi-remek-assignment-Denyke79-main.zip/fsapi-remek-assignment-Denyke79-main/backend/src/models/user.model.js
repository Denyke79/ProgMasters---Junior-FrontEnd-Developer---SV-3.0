const mongoose = require('mongoose');
const idValidator = require('mongoose-id-validator');

const UserSchema = mongoose.Schema({
    name: String,
    userName: String,
    password: String,
    role: String,
    institutions: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Institution'
    }]

}, { timestamps: true });

UserSchema.plugin(idValidator);

module.exports = mongoose.model('User', UserSchema)