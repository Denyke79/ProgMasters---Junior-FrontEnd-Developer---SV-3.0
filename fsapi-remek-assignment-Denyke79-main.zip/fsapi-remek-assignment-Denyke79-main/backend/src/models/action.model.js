const mongoose = require('mongoose');
const idValidator = require('mongoose-id-validator');

const ActionSchema = mongoose.Schema({
    date: Date,
    institutionName: String,
    shortName: String,
    institutionType: String,
    actionName: String,
    affectedName: String,
    clientType: String,
    headcount: Number,
    newClient: Boolean,
    workingMethod: String,
    activity: String,
    problem: String,
    comment: String
}, { timestamps: true });

ActionSchema.plugin(idValidator);

module.exports = mongoose.model('Action', ActionSchema)