const mongoose = require('mongoose');
const idValidator = require('mongoose-id-validator');

const InstitutionSchema = mongoose.Schema({
    name: String,
    shortName: String,
    socialWorkerName: String,
    socialWorkerEmail: String,
    socialWorkerPhone: String
}, { timestamps: true });

InstitutionSchema.plugin(idValidator);

module.exports = mongoose.model('Institution', InstitutionSchema)