const app = require('./server');
const mongoose = require('mongoose');
const supertest = require('supertest');
const Institution = require('./models/institution.model');
const Action = require('./models/action.model');
const User = require('./models/user.model');

describe('REST API integration tests', () => {
    let ACCESS_TOKEN;
    let REFRESH_TOKEN;

    const userDB = [
        { _id: 1, "username": "user", "password": "user_pw", role: "USER" },
        { _id: 2, "username": 'admin', "password": "admin_pw", role: "ADMIN" }
    ];

    const insertInstitutionData = [{
        name: "Veres Géza Iskola",
        shortName: "Mezőgazd suli",
        socialWorkerName: "Kiss Helga",
        socialWorkerEmail: "helga@kiss.hu",
        socialWorkerPhone: "+36/30-300-3000"
    }, {
        name: "Jedlik Ányos Gimnázium",
        shortName: "Jedlik gimi",
        socialWorkerName: "Kiss Helga",
        socialWorkerEmail: "helga@kiss.hu",
        socialWorkerPhone: "+36/30-300-3000"
    }, {
        name: "Tündérvár Óvoda",
        shortName: "Tündérvár ovi",
        socialWorkerName: "Nagy Péter",
        socialWorkerEmail: "peter@nagy.hu",
        socialWorkerPhone: "+36/30-400-3000"
    }];

    const insertActionData = [{
        institutionType: "gimi",
        actionName: "csoportos",
        affectedName: "9.a",
    }, {
        institutionType: "ovi",
        actionName: "passzív",
        affectedName: "11.a",
    }, {
        institutionType: "ált. suli",
        actionName: "csoportos",
        affectedName: "10.a",
    }];

    const insertUserData = [{
        name: "Kiss Helga",
        userName: "helgakiss",
        role: "admin",
    }, {
        name: "Nagy Tamás",
        userName: "tamasnagy",
        role: "user",
    }, {
        name: "Átlag Ákos",
        userName: "akiatlag",
        role: "admin",
    }];

    beforeEach(async () => {
        await mongoose.connect('mongodb://localhost:27017/SuperTestDB');
        console.log('MongoDB connection established!');
    })

    afterEach(async () => {
        await mongoose.connection.db.dropDatabase();
        await mongoose.connection.close();
        console.log('MongoDB connection closed.')
    })

    test('GET /institution endpoint', async () => {
        await Institution.insertMany(insertInstitutionData);

        const response = await supertest(app).get('/api/institution')
        expect(response.statusCode).toBe(200);
        expect(response.statusCode).toBe(200);
        expect(Array.isArray(response.body)).toBeTruthy();
        expect(response.body.length).toBe(insertInstitutionData.length);

    })

    test('GET /institution/:id endpoint', async () => {
        const testInstitution = await Institution.insertMany(insertInstitutionData);
        const firstInstitutionId = testInstitution[0]._id;

        const response = await supertest(app).get(`/api/institution/${firstInstitutionId.toString()}`).expect(200);
        expect(response.body.name).toBe(insertInstitutionData[0].name);
        expect(response.body.shortName).toBe(insertInstitutionData[0].shortName);
        expect(response.body.socialWorkerName).toBe(insertInstitutionData[0].socialWorkerName);
        expect(response.body.socialWorkerEmail).toBe(insertInstitutionData[0].socialWorkerEmail);
        expect(response.body.socialWorkerPhone).toBe(insertInstitutionData[0].socialWorkerPhone);
    });

    test('GET /institution/:id endpoint with invalid id', async () => {
        await Institution.insertMany(insertInstitutionData);
        const INVALID_INST_ID = '1';

        const response = await supertest(app).get(`/api/institution/${INVALID_INST_ID}`).expect(500);

        expect(response.body.hasError).toBe(true);
        expect(response.body.message).toBe(`Database error`);
    });

    test('GET /action endpoint as authenticated user', async () => {
        await Action.insertMany(insertActionData);

        await supertest(app)
            .post('/api/login')
            .send({
                "username": "user", "password": "user_pw"
            }).then(res => {
                ACCESS_TOKEN = res.body.accessToken;
                REFRESH_TOKEN = res.body.refreshToken;
            })

        const response = await supertest(app)
            .get('/api/action')
            .set('Authorization', `Bearer ${ACCESS_TOKEN}`);

        expect(response.statusCode).toBe(200);
        expect(Array.isArray(response.body)).toBeTruthy();
        expect(response.body.length).toBe(insertActionData.length);
    })

    test('GET /action endpoint as not authenticated user', async () => {
        await Action.insertMany(insertActionData);

        await supertest(app)
            .post('/api/login')
            .send({
                "username": "dog", "password": "cat"
            }).then(res => {
                ACCESS_TOKEN = res.body.accessToken;
                REFRESH_TOKEN = res.body.refreshToken;
            })

        const response = await supertest(app)
            .get('/api/action')
            .set('Authorization', `Bearer ${ACCESS_TOKEN}`);

        expect(response.statusCode).toBe(403);
    })

    test('GET /action/:id endpoint as authenticated user', async () => {
        const testAction = await Action.insertMany(insertActionData);
        const firstActionId = testAction[0]._id;

        await supertest(app)
            .post('/api/login')
            .send({
                "username": "user", "password": "user_pw"
            }).then(res => {
                ACCESS_TOKEN = res.body.accessToken;
                REFRESH_TOKEN = res.body.refreshToken;
            })

        const response = await supertest(app)
            .get(`/api/action/${firstActionId.toString()}`)
            .set('Authorization', `Bearer ${ACCESS_TOKEN}`)

        expect(response.statusCode).toBe(200);
        expect(response.body.actionName).toBe(testAction[0].actionName);
    });

    test('GET /action/:id endpoint as not authenticated user', async () => {
        const testAction = await Action.insertMany(insertActionData);
        const firstActionId = testAction[0]._id;

        await supertest(app)
            .post('/api/login')
            .send({
                "username": "dog", "password": "user_pw"
            }).then(res => {
                ACCESS_TOKEN = res.body.accessToken;
                REFRESH_TOKEN = res.body.refreshToken;
            })

        const response = await supertest(app)
            .get(`/api/action/${firstActionId.toString()}`)
            .set('Authorization', `Bearer ${ACCESS_TOKEN}`)

        expect(response.statusCode).toBe(403);
    });

    test('POST /action endpoint test as authenticated user', async () => {
        const postData = {
            institutionType: "ovi",
            actionName: "egyéniTAJ",
            affectedName: "12.a",
        }

        await supertest(app)
            .post('/api/login')
            .send({
                "username": "user", "password": "user_pw"
            }).then(res => {
                ACCESS_TOKEN = res.body.accessToken;
                REFRESH_TOKEN = res.body.refreshToken;
            })

        const response = await supertest(app)
            .post(`/api/action/`).send(postData)
            .set('Authorization', `Bearer ${ACCESS_TOKEN}`)

        expect(response.statusCode).toBe(201);
        expect(response.body._id).toBeTruthy();
        expect(response.body.institutionType).toBe(postData.institutionType);
        expect(response.body.actionName).toBe(postData.actionName);
        expect(response.body.affectedName).toBe(postData.affectedName);
    })

    test('POST /action endpoint test as non-authenticated user', async () => {
        const postData = {
            institutionType: "ovi",
            actionName: "egyéniTAJ",
            affectedName: "12.a",
        }

        await supertest(app)
            .post('/api/login')
            .send({
                "username": "dog", "password": "user_pw"
            }).then(res => {
                ACCESS_TOKEN = res.body.accessToken;
                REFRESH_TOKEN = res.body.refreshToken;
            })

        const response = await supertest(app)
            .post(`/api/action/`).send(postData)
            .set('Authorization', `Bearer ${ACCESS_TOKEN}`)

        expect(response.statusCode).toBe(403);
        expect(response.body._id).toBeUndefined();
    })

    test('UPDATE /action endpoint test as authenticated user', async () => {
        const postData = {
            institutionType: "ovi",
            actionName: "egyéniTAJ",
            affectedName: "12.a",
        }
        const updatedAction = {
            institutionType: "gimi",
            actionName: "egyéniTAJ",
            affectedName: "12.a",
        }

        const testAction = await Action.insertMany(postData);
        const firstActionId = testAction[0]._id;

        await supertest(app)
            .post('/api/login')
            .send({
                "username": "user", "password": "user_pw"
            }).then(res => {
                ACCESS_TOKEN = res.body.accessToken;
                REFRESH_TOKEN = res.body.refreshToken;
            })

        await Action.findByIdAndUpdate(firstActionId, updatedAction);

        const updatedElement = await Action.findById(firstActionId);

        expect(updatedElement.institutionType).toBe(updatedAction.institutionType);
        expect(updatedElement.actionName).toBe(updatedAction.actionName);
        expect(updatedElement.affectedName).toBe(updatedAction.affectedName);
    })

    test('UPDATE /action endpoint test as non-authenticated user', async () => {
        const postData = {
            institutionType: "ovi",
            actionName: "egyéniTAJ",
            affectedName: "12.a",
        }
        const updatedAction = {
            institutionType: "gimi",
            actionName: "egyéniTAJ",
            affectedName: "12.a",
        }

        const testAction = await Action.insertMany(postData);
        const firstInstitutionId = testAction[0]._id;

        await supertest(app)
            .post('/api/login')
            .send({
                "username": "dog", "password": "user_pw"
            }).then(res => {
                ACCESS_TOKEN = res.body.accessToken;
                REFRESH_TOKEN = res.body.refreshToken;
            })

        const response = await supertest(app)
            .put(`/api/action/${firstInstitutionId.toString()}`).send(updatedAction)
            .set('Authorization', `Bearer ${ACCESS_TOKEN}`)

        expect(response.statusCode).toBe(403);
    })

    test('DELETE /action endpoint test as authenticated user', async () => {
        const testAction = await Action.insertMany(insertActionData);
        const firstActionId = testAction[0]._id;

        await supertest(app)
            .post('/api/login')
            .send({
                "username": "user", "password": "user_pw"
            }).then(res => {
                ACCESS_TOKEN = res.body.accessToken;
                REFRESH_TOKEN = res.body.refreshToken;
            })

        const response = await supertest(app)
            .delete(`/api/action/${firstActionId.toString()}`)
            .set('Authorization', `Bearer ${ACCESS_TOKEN}`)

        expect(response.statusCode).toBe(200);

        const deletedAction = await Action.findById(firstActionId);
        expect(deletedAction).toBeNull();
    });

    test('DELETE /action endpoint test as non-authenticated user', async () => {
        const testAction = await Action.insertMany(insertActionData);
        const firstActionId = testAction[0]._id;

        await supertest(app)
            .post('/api/login')
            .send({
                "username": "dog", "password": "user_pw"
            }).then(res => {
                ACCESS_TOKEN = res.body.accessToken;
                REFRESH_TOKEN = res.body.refreshToken;
            })

        const response = await supertest(app)
            .delete(`/api/action/${firstActionId.toString()}`)
            .set('Authorization', `Bearer ${ACCESS_TOKEN}`)

        expect(response.statusCode).toBe(403);
    });

    test('GET /user endpoint as admin', async () => {
        await User.insertMany(insertUserData);

        await supertest(app)
            .post('/api/login')
            .send({
                "username": "admin", "password": "admin_pw"
            }).then(res => {
                ACCESS_TOKEN = res.body.accessToken;
                REFRESH_TOKEN = res.body.refreshToken;
            })

        const response = await supertest(app)
            .get('/api/user')
            .set('Authorization', `Bearer ${ACCESS_TOKEN}`);

        expect(response.statusCode).toBe(200);
        expect(Array.isArray(response.body)).toBeTruthy();
        expect(response.body.length).toBe(insertActionData.length);
    })

    test('GET /user endpoint as not admin', async () => {
        await User.insertMany(insertUserData);

        await supertest(app)
            .post('/api/login')
            .send({
                "username": "dog", "password": "cat"
            }).then(res => {
                ACCESS_TOKEN = res.body.accessToken;
                REFRESH_TOKEN = res.body.refreshToken;
            })

        const response = await supertest(app)
            .get('/api/user')
            .set('Authorization', `Bearer ${ACCESS_TOKEN}`);

        expect(response.statusCode).toBe(403);
    })

    test('GET /user/:id endpoint as admin', async () => {
        const testUser = await User.insertMany(insertUserData);
        const firstUserId = testUser[0]._id;

        await supertest(app)
            .post('/api/login')
            .send({
                "username": "admin", "password": "admin_pw"
            }).then(res => {
                ACCESS_TOKEN = res.body.accessToken;
                REFRESH_TOKEN = res.body.refreshToken;
            })

        const response = await supertest(app)
            .get(`/api/user/${firstUserId.toString()}`)
            .set('Authorization', `Bearer ${ACCESS_TOKEN}`)

        expect(response.statusCode).toBe(200);
        expect(response.body.userName).toBe(testUser[0].userName);
    });

    test('GET /user/:id endpoint as not admin', async () => {
        const testUser = await User.insertMany(insertUserData);
        const firstUserId = testUser[0]._id;

        await supertest(app)
            .post('/api/login')
            .send({
                "username": "dog", "password": "user_pw"
            }).then(res => {
                ACCESS_TOKEN = res.body.accessToken;
                REFRESH_TOKEN = res.body.refreshToken;
            })

        const response = await supertest(app)
            .get(`/api/user/${firstUserId.toString()}`)
            .set('Authorization', `Bearer ${ACCESS_TOKEN}`)

        expect(response.statusCode).toBe(403);
    });

    test('POST /user endpoint test as admin', async () => {
        const postData = {
            name: "Mózes Márton",
            userName: "momika",
            role: "user",
        }

        await supertest(app)
            .post('/api/login')
            .send({
                "username": "admin", "password": "admin_pw"
            }).then(res => {
                ACCESS_TOKEN = res.body.accessToken;
                REFRESH_TOKEN = res.body.refreshToken;
            })

        const response = await supertest(app)
            .post(`/api/user/`).send(postData)
            .set('Authorization', `Bearer ${ACCESS_TOKEN}`)

        expect(response.statusCode).toBe(201);
        expect(response.body._id).toBeTruthy();
        expect(response.body.name).toBe(postData.name);
        expect(response.body.userName).toBe(postData.userName);
        expect(response.body.role).toBe(postData.role);
    })

    test('POST /user endpoint test as non-admin', async () => {
        const postData = {
            name: "Mózes Márton",
            userName: "momika",
            role: "user",
        }

        await supertest(app)
            .post('/api/login')
            .send({
                "username": "dog", "password": "user_pw"
            }).then(res => {
                ACCESS_TOKEN = res.body.accessToken;
                REFRESH_TOKEN = res.body.refreshToken;
            })

        const response = await supertest(app)
            .post(`/api/user/`).send(postData)
            .set('Authorization', `Bearer ${ACCESS_TOKEN}`)

        expect(response.statusCode).toBe(403);
        expect(response.body._id).toBeUndefined();
    })

    test('UPDATE /user endpoint test as admin', async () => {
        const postData = {
            name: "Mózes Márton",
            userName: "momika",
            role: "user",
        }
        const updatedUser = {
            name: "Mózes Eb",
            userName: "momika",
            role: "user",
        }

        const testUser = await User.insertMany(postData);
        const firstUserId = testUser[0]._id;

        await supertest(app)
            .post('/api/login')
            .send({
                "username": "admin", "password": "admin_pw"
            }).then(res => {
                ACCESS_TOKEN = res.body.accessToken;
                REFRESH_TOKEN = res.body.refreshToken;
            })

        await User.findByIdAndUpdate(firstUserId, updatedUser);

        const updatedElement = await User.findById(firstUserId);

        expect(updatedElement.name).toBe(updatedUser.name);
        expect(updatedElement.userName).toBe(updatedUser.userName);
        expect(updatedElement.role).toBe(updatedUser.role);
    })

    test('UPDATE /user endpoint test as non-admin', async () => {
        const postData = {
            name: "Mózes Márton",
            userName: "momika",
            role: "user",
        }
        const updatedUser = {
            name: "Mózes Eb",
            userName: "momika",
            role: "user",
        }

        const testUser = await User.insertMany(postData);
        const firstUserId = testUser[0]._id;

        await supertest(app)
            .post('/api/login')
            .send({
                "username": "dog", "password": "user_pw"
            }).then(res => {
                ACCESS_TOKEN = res.body.accessToken;
                REFRESH_TOKEN = res.body.refreshToken;
            })

        const response = await supertest(app)
            .put(`/api/user/${firstUserId.toString()}`).send(updatedUser)
            .set('Authorization', `Bearer ${ACCESS_TOKEN}`)

        expect(response.statusCode).toBe(403);
    })

    test('DELETE /user endpoint test as admin', async () => {
        const testUser = await User.insertMany(insertUserData);
        const firstUserId = testUser[0]._id;

        await supertest(app)
            .post('/api/login')
            .send({
                "username": "admin", "password": "admin_pw"
            }).then(res => {
                ACCESS_TOKEN = res.body.accessToken;
                REFRESH_TOKEN = res.body.refreshToken;
            })

        const response = await supertest(app)
            .delete(`/api/user/${firstUserId.toString()}`)
            .set('Authorization', `Bearer ${ACCESS_TOKEN}`)

        expect(response.statusCode).toBe(200);

        const deletedUser = await User.findById(firstUserId);
        expect(deletedUser).toBeNull();
    });

    test('DELETE /user endpoint test as non-admin', async () => {
        const testUser = await User.insertMany(insertUserData);
        const firstUserId = testUser[0]._id;

        await supertest(app)
            .post('/api/login')
            .send({
                "username": "dog", "password": "admin_pw"
            }).then(res => {
                ACCESS_TOKEN = res.body.accessToken;
                REFRESH_TOKEN = res.body.refreshToken;
            })

        const response = await supertest(app)
            .delete(`/api/user/${firstUserId.toString()}`)
            .set('Authorization', `Bearer ${ACCESS_TOKEN}`)

        expect(response.statusCode).toBe(403);
    });

});