import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class BaseHttpService<T extends { _id?: string }> {

  BASE_URL = environment.apiUrl;

  constructor(private http: HttpClient, entity: String) {
    this.BASE_URL += entity;
  }

  create(entityObj: T): Observable<T> {
    return this.http.post<T>(`${this.BASE_URL}`, entityObj);
  }

  findById(_id: string): Observable<T> {
    return this.http.get<T>(`${this.BASE_URL}/${_id}`);
  }

  findAll(): Observable<T[]> {
    return this.http.get<T[]>(`${this.BASE_URL}`);
  }

  update(entityObj: T): Observable<T> {
    return this.http.put<T>(`${this.BASE_URL}/${entityObj._id}`, entityObj)
  }

  delete(_id: string): Observable<T> {
    return this.http.delete<T>(`${this.BASE_URL}/${_id}`)
  }

  setAuthentication(): HttpHeaders {
    let headers = new HttpHeaders();
    if (localStorage.getItem('accessToken')) {
      headers = headers.set('Authorization', `Bearer ${localStorage.getItem('accessToken')}`)
    }
    return headers;
  }
}
