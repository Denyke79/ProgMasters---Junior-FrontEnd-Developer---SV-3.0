import { Injectable } from '@angular/core';
import { BaseHttpService } from './base-http.service';
import { HttpClient } from '@angular/common/http';
import { ActionModel } from '../models/action.model';

@Injectable({
  providedIn: 'root'
})
export class ActionHttpService extends BaseHttpService<ActionModel> {

  constructor(http: HttpClient) {
    super(http, 'action')
  }
}
