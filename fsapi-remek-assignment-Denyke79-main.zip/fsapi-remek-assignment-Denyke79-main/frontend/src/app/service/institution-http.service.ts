import { Injectable } from '@angular/core';
import { BaseHttpService } from './base-http.service';
import { HttpClient } from '@angular/common/http';
import { InstitutionModel } from 'src/app/models/institution.model';

@Injectable({
  providedIn: 'root'
})
export class InstitutionHttpService extends BaseHttpService<InstitutionModel> {

  constructor(http: HttpClient) {
    super(http, 'institution')
  }
}
