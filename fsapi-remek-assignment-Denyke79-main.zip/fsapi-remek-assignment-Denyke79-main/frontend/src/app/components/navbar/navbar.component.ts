import { Component, OnDestroy, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { UserModel } from 'src/app/models/user.model';
import { AuthService } from 'src/app/service/auth.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit, OnDestroy {

  user: UserModel | null = null;
  loginStatus = false;
  userSub?: Subscription;


  constructor(private authService: AuthService, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.getMe();
    this.userSub = this.authService.userObject.subscribe(
      (user) => {
        this.user = user;
        this.loginStatus = true;
      }
    )
  }

  ngOnDestroy(): void {
    this.userSub?.unsubscribe();
  }

  getMe() {
    if (localStorage.getItem('accessToken')) {
      this.authService.me().subscribe();
    }
  }

  logout(): void {
    this.loginStatus = false;
    this.authService.logout();
    this.toastr.warning('Sikeres kijelentkezés!')

  }

}
