import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ActionModel } from 'src/app/models/action.model';
import { ActionHttpService } from 'src/app/service/action-http.service';

@Component({
  selector: 'app-administration',
  templateUrl: './administration.component.html',
  styleUrls: ['./administration.component.scss']
})
export class AdministrationComponent implements OnInit {

  actions!: ActionModel[];

  page: number = 1;
  pageSize: number = 50;

  inputText: string = "";
  phraseKey: string = "notset";

  constructor(private actionHttpService: ActionHttpService, private router: Router, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.actionHttpService.findAll()
      .subscribe({
        next: (action) => {
          this.actions = action
        },
        error: (err) => {
          console.error(err);
        }
      })
  }

  public addAction() {
    this.router.navigate(['new']);
  }

  public showAction(actionId: string) {
    this.router.navigate(['administration', actionId]);
  }

  public updateAction(actionId: string) {
    this.router.navigate(['administration', actionId, 'edit'])
  }

  public deleteAction(actionId: string) {
    if (actionId && confirm(`Biztosan véglegesen törölni szeretnéd ezt az esetet?`)) {
      this.toastr.error('Sikeresen törölted az esetet.', 'Sikeres törlés!')
      this.actionHttpService.delete(actionId).subscribe();
      this.actionHttpService.findAll()
        .subscribe({
          next: (action) => {
            this.actions = action
          },
          error: (err) => {
            console.error(err);
          }
        })
    }
  }

}
