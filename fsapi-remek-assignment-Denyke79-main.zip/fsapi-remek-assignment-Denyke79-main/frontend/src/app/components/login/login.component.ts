import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/service/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm!: FormGroup;

  constructor(private authService: AuthService, private router: Router, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.loginForm = new FormGroup({
      username: new FormControl(''),
      password: new FormControl('')
    })
  }

  onSubmit() {
    const personLog = this.loginForm.value;
    this.authService.login(personLog).subscribe({
      next: () => {
        this.toastr.success('Sikeres bejelentkezés');
        this.router.navigate(['home2'])
      },
      error: () => {
        this.toastr.warning('Sikertelen bejelentkezés');
        this.loginForm.reset();
      }
    })
  }

}
