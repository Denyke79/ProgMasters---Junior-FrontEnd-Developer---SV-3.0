import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ActionModel } from 'src/app/models/action.model';
import { InstitutionModel } from 'src/app/models/institution.model';
import { ActionHttpService } from 'src/app/service/action-http.service';
import { InstitutionHttpService } from 'src/app/service/institution-http.service';

@Component({
  selector: 'app-action-update',
  templateUrl: './action-update.component.html',
  styleUrls: ['./action-update.component.scss']
})
export class ActionUpdateComponent implements OnInit {

  updateActionForm: FormGroup = new FormGroup({
    date: new FormControl('', [Validators.required]),
    institutionName: new FormControl('', [Validators.required]),
    shortName: new FormControl('', [Validators.required]),
    institutionType: new FormControl('', [Validators.required]),
    actionName: new FormControl('', [Validators.required]),
    affectedName: new FormControl('', [Validators.required]),
    clientType: new FormControl('', [Validators.required]),
    headcount: new FormControl('', [Validators.required]),
    newClient: new FormControl('', [Validators.required]),
    workingMethod: new FormControl('', [Validators.required]),
    activity: new FormControl('', [Validators.required]),
    problem: new FormControl('', [Validators.required]),
    comment: new FormControl('')
  })

  get date() { return this.updateActionForm.get('date'); }
  get institutionName() { return this.updateActionForm.get('institutionName'); }
  get shortName() { return this.updateActionForm.get('shortName'); }
  get institutionType() { return this.updateActionForm.get('institutionType'); }
  get actionName() { return this.updateActionForm.get('actionName'); }
  get affectedName() { return this.updateActionForm.get('affectedName'); }
  get clientType() { return this.updateActionForm.get('clientType'); }
  get headcount() { return this.updateActionForm.get('headcount'); }
  get newClient() { return this.updateActionForm.get('newClient'); }
  get workingMethod() { return this.updateActionForm.get('workingMethod'); }
  get activity() { return this.updateActionForm.get('activity'); }
  get problem() { return this.updateActionForm.get('problem'); }
  get comment() { return this.updateActionForm.get('comment'); }

  updateActionId?: string;

  @ViewChild('submitBtn') btn?: ElementRef<HTMLButtonElement>;

  institutions!: InstitutionModel[];

  constructor(
    private actionHttpService: ActionHttpService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private toastr: ToastrService,
    private institutionHttpService: InstitutionHttpService) { }

  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe({
      next: (params: ParamMap) => {
        let actionId = params.get('id');
        if (actionId) {
          this.actionHttpService.findById(actionId).subscribe({
            next: data => {
              const date = new Date(data.date);
              const formattedDate = `${date.getFullYear()}-${('0' + (date.getMonth() + 1)).slice(-2)}-${('0' + date.getDate()).slice(-2)}`;
              this.updateActionForm.patchValue({
                ...data,
                date: formattedDate
              });
              this.updateActionId = data._id;
            }
          })
        }
      }
    })

    this.institutionHttpService.findAll()
      .subscribe({
        next: (institution) => {
          this.institutions = institution;
        },
        error: (err) => {
          console.error(err);
        }
      })
  }

  saveForm() {
    if (this.updateActionForm.valid) {
      const updatedAction: ActionModel = {
        _id: this.updateActionId,
        ...this.updateActionForm.value
      }
      console.log(this.updateActionId);
      this.actionHttpService.update(updatedAction).subscribe({
        next: (savedAction) => {
          this.toastr.success('Sikeresen frissítetted az esetet.', 'Sikeres frissítés!')
          this.router.navigate(['administration'])
        }
      })
    }
  }

  goBack() {
    this.router.navigate(['administration']);
  }
}
