import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ActionHttpService } from 'src/app/service/action-http.service';
import { ToastrService } from 'ngx-toastr';
import { InstitutionHttpService } from 'src/app/service/institution-http.service';
import { InstitutionModel } from 'src/app/models/institution.model';

@Component({
  selector: 'app-new-action',
  templateUrl: './new-action.component.html',
  styleUrls: ['./new-action.component.scss']
})
export class NewActionComponent implements OnInit {

  newActionForm: FormGroup = new FormGroup({
    date: new FormControl('', [Validators.required]),
    institutionName: new FormControl('', [Validators.required]),
    shortName: new FormControl('', [Validators.required]),
    institutionType: new FormControl('', [Validators.required]),
    actionName: new FormControl('', [Validators.required]),
    affectedName: new FormControl('', [Validators.required]),
    clientType: new FormControl('', [Validators.required]),
    headcount: new FormControl('', [Validators.required]),
    newClient: new FormControl('', [Validators.required]),
    workingMethod: new FormControl('', [Validators.required]),
    activity: new FormControl('', [Validators.required]),
    problem: new FormControl('', [Validators.required]),
    comment: new FormControl('')
  })

  get date() { return this.newActionForm.get('date'); }
  get institutionName() { return this.newActionForm.get('institutionName'); }
  get shortName() { return this.newActionForm.get('shortName'); }
  get institutionType() { return this.newActionForm.get('institutionType'); }
  get actionName() { return this.newActionForm.get('actionName'); }
  get affectedName() { return this.newActionForm.get('affectedName'); }
  get clientType() { return this.newActionForm.get('clientType'); }
  get headcount() { return this.newActionForm.get('headcount'); }
  get newClient() { return this.newActionForm.get('newClient'); }
  get workingMethod() { return this.newActionForm.get('workingMethod'); }
  get activity() { return this.newActionForm.get('activity'); }
  get problem() { return this.newActionForm.get('problem'); }
  get comment() { return this.newActionForm.get('comment'); }

  @ViewChild('submitBtn') btn?: ElementRef<HTMLButtonElement>;

  institutions!: InstitutionModel[];

  constructor(
    private actionHttpService: ActionHttpService,
    private router: Router,
    private toastr: ToastrService,
    private institutionHttpService: InstitutionHttpService) { }

  ngOnInit(): void {
    this.institutionHttpService.findAll()
      .subscribe({
        next: (institution) => {
          this.institutions = institution;
        },
        error: (err) => {
          console.error(err);
        }
      })
  }

  saveForm() {
    const newAction = this.newActionForm.value;

    this.actionHttpService.create(newAction).subscribe({
      next: (savedAction) => {
        console.log(savedAction);
        this.toastr.success('Sikeresen elmentetted az új esetet.', 'Sikeres mentés!')
      },
      error: err => {
        console.error(err);
        this.toastr.warning('Nem sikerült menteni az új esetet.', 'Sikertelen mentés!')
      },
      complete: () => {
        this.router.navigate(['administration']);
      }
    });
  }

  goBack() {
    this.router.navigate(['administration']);
  }
}
