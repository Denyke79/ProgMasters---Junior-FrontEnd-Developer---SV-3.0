import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ActionModel } from 'src/app/models/action.model';
import { ActionHttpService } from 'src/app/service/action-http.service';

@Component({
  selector: 'app-action',
  templateUrl: './action.component.html',
  styleUrls: ['./action.component.scss']
})
export class ActionComponent implements OnInit {

  public action!: ActionModel;

  constructor(private actionHttpService: ActionHttpService, private router: Router, private activatedRoute: ActivatedRoute, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe({
      next: (params: ParamMap) => {
        let actionId = params.get('id');
        if (actionId) {
          this.actionHttpService.findById(actionId).subscribe({
            next: data => { this.action = data }
          })
        }
      }
    })
  }

  goBack() {
    this.router.navigate(['administration']);
  }

  goUpdate(actionId: string) {
    this.router.navigate(['administration', actionId, 'edit'])
  }

  delete(actionId: string) {
    if (actionId && confirm(`Biztosan véglegesen törölni szeretnéd ezt az esetet?`)) {
      this.actionHttpService.delete(actionId).subscribe();
      this.toastr.error('Sikeresen törölted az esetet.', 'Sikeres törlés!')
      this.router.navigate(['administration']);
    }
  }

}
