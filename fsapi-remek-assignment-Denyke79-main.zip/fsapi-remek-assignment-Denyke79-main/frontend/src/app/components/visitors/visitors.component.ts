import { Component, OnInit } from '@angular/core';
import { InstitutionModel } from 'src/app/models/institution.model';
import { InstitutionHttpService } from 'src/app/service/institution-http.service';

@Component({
  selector: 'app-visitors',
  templateUrl: './visitors.component.html',
  styleUrls: ['./visitors.component.scss']
})
export class VisitorsComponent implements OnInit {

  institutions!: InstitutionModel[];

  page = 1;
  pageSize = 25;

  inputText: string = "";

  constructor(private institutionHttpService: InstitutionHttpService) { }

  ngOnInit(): void {
    this.institutionHttpService.findAll()
      .subscribe({
        next: (institution) => {
          this.institutions = institution;
        },
        error: (err) => {
          console.error(err);
        }
      })
  }
}
