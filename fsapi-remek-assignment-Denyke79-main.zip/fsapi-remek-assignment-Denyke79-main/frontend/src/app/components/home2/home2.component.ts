import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserModel } from 'src/app/models/user.model';
import { AuthService } from 'src/app/service/auth.service';

@Component({
  selector: 'app-home2',
  templateUrl: './home2.component.html',
  styleUrls: ['./home2.component.scss']
})
export class Home2Component implements OnInit {

  user: UserModel | null = null;

  constructor(private authService: AuthService, private router: Router) { }

  ngOnInit(): void {
    this.getMe();
    this.authService.userObject.subscribe(
      (user) => {
        this.user = user;
      }
    )
  }

  getMe() {
    if (localStorage.getItem('accessToken')) {
      this.authService.me().subscribe();
    }
  }

  goAdministration() {
    this.router.navigate(['administration']);
  }

  goStatistic() {
    this.router.navigate(['statistic']);
  }

  goLinks() {
    this.router.navigate(['links']);
  }
}
