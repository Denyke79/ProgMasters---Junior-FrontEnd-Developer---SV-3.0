import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { AuthenticationInterceptor } from 'src/interceptors/authentication.interceptor';
import { NavbarComponent } from './components/navbar/navbar.component';
import { FooterComponent } from './components/footer/footer.component';
import { HomeComponent } from './components/home/home.component';
import { IntroductionComponent } from './components/introduction/introduction.component';
import { FaqComponent } from './components/faq/faq.component';
import { VisitorsComponent } from './components/visitors/visitors.component';
import { AdministrationComponent } from './components/administration/administration.component';
import { LinksComponent } from './components/links/links.component';
import { Home2Component } from './components/home2/home2.component';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { LoginComponent } from './components/login/login.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbPaginationModule } from '@ng-bootstrap/ng-bootstrap';
import { SearchFilterPipe } from './pipes/search-filter.pipe';
import { NewActionComponent } from './components/new-action/new-action.component';
import { ActionUpdateComponent } from './components/action-update/action-update.component';
import { ActionComponent } from './components/action/action.component';
import { SearchAdministrationPipe } from './pipes/search-administration.pipe';
import { NotAuthComponent } from './components/not-auth/not-auth.component';
import { ToastrModule } from 'ngx-toastr';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    FooterComponent,
    HomeComponent,
    IntroductionComponent,
    FaqComponent,
    VisitorsComponent,
    AdministrationComponent,
    LinksComponent,
    Home2Component,
    NotFoundComponent,
    LoginComponent,
    SearchFilterPipe,
    NewActionComponent,
    ActionUpdateComponent,
    ActionComponent,
    SearchAdministrationPipe,
    NotAuthComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    HttpClientModule,
    NgbModule,
    NgbPaginationModule,
    ReactiveFormsModule,
    FormsModule,
    ToastrModule.forRoot()
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AuthenticationInterceptor, multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
