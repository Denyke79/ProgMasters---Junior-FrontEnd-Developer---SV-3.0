import { Pipe, PipeTransform } from '@angular/core';
import { InstitutionModel } from '../models/institution.model';

@Pipe({
  name: 'searchFilter'
})
export class SearchFilterPipe implements PipeTransform {

  transform(institutions: any[], searchText: string): InstitutionModel[] {
    if (!institutions || !searchText) {
      return institutions;
    }
    searchText = searchText.toLowerCase();

    return institutions.filter(inst => {
      let isOk: boolean = false;
      for (let k in inst) {
        let check = inst[k].toString().toLowerCase();
        if (check.indexOf(searchText) > -1) {
          isOk = true;
        }
      }
      return isOk;

      // return institution.name.toLowerCase().includes(searchText);
    })
  }

}
