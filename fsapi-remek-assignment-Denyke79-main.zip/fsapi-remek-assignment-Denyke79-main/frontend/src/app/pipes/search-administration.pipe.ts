import { Pipe, PipeTransform } from '@angular/core';
import { ActionModel } from '../models/action.model'

@Pipe({
  name: 'searchAdministration'
})
export class SearchAdministrationPipe implements PipeTransform {

  transform(actions: any[], searchText: string, key: string): ActionModel[] {
    if (!actions || !searchText) {
      return actions;
    }
    searchText = searchText.toLowerCase();

    return actions.filter(action => {
      if (!key || key == 'notset') {
        let isOk: boolean = false;
        for (let k in action) {
          let check = action[k].toString().toLowerCase();
          if (check.indexOf(searchText) > -1) {
            isOk = true;
          }
        }
        return isOk;
      } else {
        let check = action[key].toString().toLowerCase();
        return check.indexOf(searchText) > -1;
      }
    })
  }
}
