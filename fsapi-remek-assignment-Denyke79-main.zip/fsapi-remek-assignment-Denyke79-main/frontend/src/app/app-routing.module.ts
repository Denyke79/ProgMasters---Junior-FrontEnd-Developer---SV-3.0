import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { IntroductionComponent } from './components/introduction/introduction.component';
import { VisitorsComponent } from './components/visitors/visitors.component';
import { FaqComponent } from './components/faq/faq.component';
import { Home2Component } from './components/home2/home2.component';
import { AdministrationComponent } from './components/administration/administration.component';
import { LinksComponent } from './components/links/links.component';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { NewActionComponent } from './components/new-action/new-action.component';
import { ActionUpdateComponent } from './components/action-update/action-update.component';
import { ActionComponent } from './components/action/action.component';
import { NotAuthComponent } from './components/not-auth/not-auth.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'introduction', component: IntroductionComponent },
  { path: 'visitors', component: VisitorsComponent },
  { path: 'faq', component: FaqComponent },
  { path: 'home2', component: Home2Component },
  { path: 'administration', component: AdministrationComponent },
  { path: 'administration/:id', component: ActionComponent },
  { path: 'administration/:id/edit', component: ActionUpdateComponent },
  { path: 'new', component: NewActionComponent },
  { path: 'links', component: LinksComponent },
  { path: 'login', component: NotAuthComponent },
  { path: '**', component: NotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
