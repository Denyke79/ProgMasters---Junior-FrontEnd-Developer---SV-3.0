export interface UserModel {
  username: string,
  name: string,
  role: string,
  user_id: string
}
