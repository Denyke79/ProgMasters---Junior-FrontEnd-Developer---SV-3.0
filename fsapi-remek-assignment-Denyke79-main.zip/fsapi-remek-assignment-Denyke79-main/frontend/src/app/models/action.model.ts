export interface ActionModel {
  _id: string,
  date: Date,
  institutionName: string,
  shortName: string,
  institutionType: string,
  actionName: string,
  affectedName: string,
  clientType: string,
  headcount: number,
  newClient: boolean,
  workingMethod: string,
  activity: string,
  problem: string,
  comment: string
}
