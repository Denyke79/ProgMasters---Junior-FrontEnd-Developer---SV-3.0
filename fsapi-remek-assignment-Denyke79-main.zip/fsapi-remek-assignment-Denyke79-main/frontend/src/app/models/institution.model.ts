export interface InstitutionModel {
  name: string,
  shortName: string,
  socialWorkerName: string,
  socialWorkerEmail: string,
  socialWorkerPhone: string,
  _id: string
}
